tmp <- read.csv("Results/SimVsEst.csv");

pdf(file = "Results/Graphics/SimVsEst.pdf")
plot(tmp, xlab = "Simulated", ylab = "Estimated", las = 1);
abline(0,1)
dev.off()
