#!/usr/bin/python

import sys
import re # regular expression

#for line in sys.argv:
#    print line

for line in sys.stdin:
    if(re.search('partition', line)):
        ModelTimeStep = re.search('\[(.*)]', line)
        print(ModelTimeStep.group(1))
        #sys.stdout.write(line)
