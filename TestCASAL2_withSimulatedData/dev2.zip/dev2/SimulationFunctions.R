# CREATED   1 August 2018
# MODIFIED 22 August 2018

# PURPOSE function for the simulation study

# Useful library
library(SAFR)

# Von Bertalanffy growth function
suppressMessages(library(FSA)) # Lots of growth function implemented in FSA
vbgf <- vbFuns("vonBertalanffy")

#
# This function simulate numbers at age in population over multiple year
# Every year, the number of individuals decrease because
#             1. 1/2 natural mortality (continuous process)
#             2. fishing (a pulse removal of catches)
#             3. 1/2 natural mortality (continuous process)

Simulate.pulsefishing.Fishery <- function(max.age = 10, nb.of.cohort = 20, exploitation.rate = c(0.2, 0.2), nat.mort.range = c(0.1, 0.8), recruitment.range=c(1e6, 1e7), log.para.range = c(8,12), log.parb.range = c(1,3), verbose = FALSE){

# Some parameters
#max.age <- 10; nb.of.cohort <- 20 # be aware that nb.of.cohort / max.age >= 3
                               # for some algorithm below to work
#age <- matrix(seq(0, max.age), nrow = nb.of.cohort, ncol = max.age+1, byrow=T)

# Exploitation rate
n.year <- nb.of.cohort - max.age + 1
yearly.exploitation.rate <- runif(nb.of.cohort, min = exploitation.rate[1], max = exploitation.rate[2])
ExplRate.faced.by.each.cohort <- matrix(nrow = nb.of.cohort, ncol = max.age)
for(i in 1:nb.of.cohort) ExplRate.faced.by.each.cohort[i,] <- yearly.exploitation.rate[seq(i, i + max.age - 1)]


n <- max.age-1
#selectivity.at.age <- c(0,0,seq(1/(max.age - 3), (max.age - 4)/(max.age - 3), length = max.age - 4), 1,1)
#selectivity.at.age <- c(0,0,seq(1/(max.age - 5), (max.age - 6)/(max.age - 5), length = max.age - 8), rep(1,6))
#log.para <- runif(1, min = log.para.range[1], max=log.para.range[2])
#if(verbose) print(paste("Logistic parameter a is", log.para))
#log.parb <- runif(1, min = log.parb.range[1], max=log.parb.range[2])
#if(verbose) print(paste("Logistic parameter b is", log.parb))

#selectivity.at.age <- logistic(log.para,log.parb,seq(1,max.age))

## Weight at age

## vector of length at age (L0 and Linf in cm)

#
# WARNING: here CASAL2 starts age from 1 rather than 0!!!!
#
# at the beginning of the year interval
v.Length.at.age.y.0 <- vbgf(t=seq(1, max.age), Linf = vbgf.par[1], K=vbgf.par[2], L0=vbgf.par[3])
# at the middle of the year interval
v.Length.at.age.y.0.5 <- vbgf(t=seq(1, max.age) + 0.5, Linf = vbgf.par[1], K=vbgf.par[2], L0=vbgf.par[3])
# at the end of the year interval
v.Length.at.age.y.1 <- vbgf(t=seq(1, max.age) + 1, Linf = vbgf.par[1], K=vbgf.par[2], L0=vbgf.par[3])

# Length-Weight relationship (giving weight in kg when length are in cm)
a <- 1e-6
b <- 3

## vector of weight

# at age a the beginning of the year
v.Weight.at.age.y.0 <- a * v.Length.at.age.y.0^b
# at the middle of the year interval
v.Weight.at.age.y.0.5 <- a * v.Length.at.age.y.0.5^b
# at the end of the year interval
v.Weight.at.age.y.1 <- a * v.Length.at.age.y.1^b

## matrix of weight

# at age at the beginning of the year
M.Weight.at.age.y.0 <- outer(rep(1, n.year), v.Weight.at.age.y.0)

# at the middle of the year interval
M.Weight.at.age.y.0.5 <- outer(rep(1, n.year), v.Weight.at.age.y.0.5)

# at the end of the year interval
M.Weight.at.age.y.1 <- outer(rep(1, n.year), v.Weight.at.age.y.1)

# Natural mortality
M <- runif(1, min = nat.mort.range[1], max = nat.mort.range[2])
if(verbose) print(paste("Simulated natural mortality is", round(M,3)))

# Recruitment: N(0)
Recruitment <- runif(nb.of.cohort, min = recruitment.range[1], max = recruitment.range[2])

# Nb at age in cohorts
cohort.nb.at.beginningOfYearInterval <- matrix(nrow = nb.of.cohort, ncol = max.age)
cohort.nb.after.FirstHalfNatMort <- matrix(nrow = nb.of.cohort, ncol = max.age)
cohort.nb.after.catch <- matrix(nrow = nb.of.cohort, ncol = max.age)
cohort.nb.after.SecondHalfNatMort <- matrix(nrow = nb.of.cohort, ncol = max.age)
cohort.catch <- matrix(nrow = nb.of.cohort, ncol = max.age)

cohort.nb.at.beginningOfYearInterval[,1] <- Recruitment

for(i in 1:nrow(cohort.nb.at.beginningOfYearInterval)){
      for(j in 1:ncol(cohort.nb.at.beginningOfYearInterval)){
      
      # Apply first 1/2 natural mortality
      cohort.nb.after.FirstHalfNatMort[i,j] <- cohort.nb.at.beginningOfYearInterval[i,j] * exp(-M/2)

      ## Remove catch

      # Catch is proportional to exploitation rate
      cohort.catch[i,j] <- ExplRate.faced.by.each.cohort[i,j] * cohort.nb.after.FirstHalfNatMort[i,j]
      cohort.nb.after.catch[i,j] <- cohort.nb.after.FirstHalfNatMort[i,j] - cohort.catch[i,j]

      # Apply second 1/2 natural mortality
      cohort.nb.after.SecondHalfNatMort[i,j] <- cohort.nb.after.catch[i,j] * exp(-M/2)

      # Ageing
      if(j < ncol(cohort.nb.at.beginningOfYearInterval))
      	   cohort.nb.at.beginningOfYearInterval[i,j+1] <- cohort.nb.after.SecondHalfNatMort[i,j]
}
}

return(list(nb.at.beginningOfYearInterval = Coaa2Caaa(cohort.nb.at.beginningOfYearInterval),
            nb.after.FirstHalfNatMort = Coaa2Caaa(cohort.nb.after.FirstHalfNatMort),
	    nb.after.catch = Coaa2Caaa(cohort.nb.after.catch),
            nb.after.SecondHalfNatMort = Coaa2Caaa(cohort.nb.after.SecondHalfNatMort),
	    catch = Coaa2Caaa(cohort.catch),
	    M = M,
	    yearly.exploitation.rate = yearly.exploitation.rate,

	    #
	    # WARNING: CASAL2 does not assume the fish grow within the year
	    #
	    
	    #INSTEAD OF biomass.after.FirstHalfNatMort = Coaa2Caaa(cohort.nb.after.FirstHalfNatMort) * M.Weight.at.age.y.0,
	    biomass.after.FirstHalfNatMort = Coaa2Caaa(cohort.nb.after.FirstHalfNatMort) * M.Weight.at.age.y.0,
	    biomass.after.catch = Coaa2Caaa(cohort.nb.after.catch) * M.Weight.at.age.y.0,
	    biomass.after.SecondHalfNatMort = Coaa2Caaa(cohort.nb.after.SecondHalfNatMort) * M.Weight.at.age.y.0,
	    catch.in.biomass = Coaa2Caaa(cohort.catch) * M.Weight.at.age.y.0))

}



