# CREATED  23 May 2018
# MODIFIED 20 Aug 2018

# PURPOSE create the input for CASAL2 that describes the population structure

filename = "./fishery.csl2"

cat(file = filename, "## CREATED  23 Jul 2018\n")
cat(file = filename, "## MODIFIED 20 Aug 2018\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "## an age-structured model\n", append = TRUE)

cat(file = filename, "@model\n", append = TRUE)
cat(file = filename, "type age\n", append = TRUE)
cat(file = filename, "min_age 1\n", append = TRUE)
cat(file = filename, paste("max_age", combination.of.par$max.age[i],"\n"), append = TRUE)
cat(file = filename, "age_plus false\n", append = TRUE)
cat(file = filename, "start_year 1970\n", append = TRUE)
cat(file = filename, paste("final_year", 1970 + combination.of.par$nb.of.cohort[i] - combination.of.par$max.age[i],"\n"), append = TRUE)
cat(file = filename, "base_weight_units kgs\n", append = TRUE)
cat(file = filename, "time_steps January-April May-August September-December\n", append = TRUE)
cat(file = filename, "initialisation_phases Fixed\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@initialisation_phase Fixed\n", append = TRUE)
cat(file = filename, "type state_category_by_age\n", append = TRUE)
cat(file = filename, "categories some_species\n", append = TRUE)
cat(file = filename, "min_age 1\n", append = TRUE)
cat(file = filename, paste("max_age", combination.of.par$max.age[i],"\n"), append = TRUE)
cat(file = filename, "table n\n", append = TRUE)
cat(file = filename, "some_species ", append = TRUE)
cat(file = filename, round(c(0,sim$nb.after.SecondHalfNatMort[1,seq(1,  combination.of.par$max.age[i]-1)]),3), append = TRUE)
cat(file = filename, "\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@categories\n", append = TRUE)
cat(file = filename, "format Stock\n", append = TRUE)
cat(file = filename, "names some_species\n", append = TRUE)
cat(file = filename, "age_lengths age_size\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "# Sequence of processes affecting the stock\n", append = TRUE)
cat(file = filename, "@time_step January-April\n", append = TRUE)
cat(file = filename, "processes Recruitment NaturalMortality\n", append = TRUE)
cat(file = filename, "@time_step May-August\n", append = TRUE)
cat(file = filename, "processes Fishery\n", append = TRUE)
cat(file = filename, "@time_step September-December\n", append = TRUE)
cat(file = filename, "processes NaturalMortality Ageing\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "## Recruitment\n", append = TRUE)
cat(file = filename, "@process Recruitment\n", append = TRUE)
cat(file = filename, "type recruitment_constant\n", append = TRUE)
cat(file = filename, "categories some_species\n", append = TRUE)
cat(file = filename, "proportions 1\n", append = TRUE)
cat(file = filename, paste("r0 ", formatC(sim.rec, format = "d"), "\n"), append = TRUE) ## R0 is numbers, you could also specify B0\n", append = TRUE)
cat(file = filename, "age 1\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@process Ageing\n", append = TRUE)
cat(file = filename, "type ageing\n", append = TRUE)
cat(file = filename, "categories some_species\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

### here we will output yields

cat(file = filename, "@process NaturalMortality\n", append = TRUE)
cat(file = filename, "type mortality_constant_rate\n", append = TRUE)
cat(file = filename, "categories some_species\n", append = TRUE)
cat(file = filename, "selectivities One\n", append = TRUE)
cat(file = filename, paste("m ", sim$M/2, "\n", sep=""), append = TRUE) # M/2 because applied in 2 time-steps

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@process Fishery\n", append = TRUE)
cat(file = filename, "type mortality_event_biomass\n", append = TRUE)
cat(file = filename, "categories some_species\n", append = TRUE)
cat(file = filename, paste("years   1970:", 1970 + combination.of.par$nb.of.cohort[i] - combination.of.par$max.age[i], "\n", sep=""), append=TRUE)
cat(file = filename, "catches ", append = TRUE)
cat(file = filename, round(rowSums(sim$catch.in.biomass),5), append = TRUE)
cat(file = filename, "\n", append = TRUE)
cat(file = filename, "U_max 0.9\n", append = TRUE)
cat(file = filename, "selectivities One\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@selectivity One\n", append = TRUE)
cat(file = filename, "type constant\n", append = TRUE)
cat(file = filename, "c 1\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

#vbgf.par[1], K=vbgf.par[2], L0=vbgf.par[3]

cat(file = filename, "@age_length age_size\n", append = TRUE)
cat(file = filename, "type von_bertalanffy\n", append = TRUE)
cat(file = filename, paste("linf", vbgf.par[1], "\n"), append = TRUE)
cat(file = filename, paste("k", vbgf.par[2], "\n"), append = TRUE)
# with Linf = 100, k=0.5, L0=0: t0 = 1/k * log( (Linf - L0)/Linf)
cat(file = filename, paste("t0", vbgf.par[3], "\n"), append = TRUE)
cat(file = filename, "length_weight Length_Weight\n", append = TRUE)

cat(file = filename, "\n", append = TRUE)

cat(file = filename, "@length_weight Length_Weight\n", append = TRUE)
cat(file = filename, "type basic\n", append = TRUE)
cat(file = filename, "units kgs\n", append = TRUE)
cat(file = filename, "a 1e-06\n", append = TRUE)
cat(file = filename, "b 3\n", append = TRUE)

